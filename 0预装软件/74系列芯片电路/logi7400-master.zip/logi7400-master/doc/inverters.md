# Inverters

| Type                | Gates | Inputs per gate | Comments              |
| ------------------- |:-----:|:---------------:| --------------------- |
| [7404](7404.md)     |   6   |        1        |                       |
| [7405](7405.md)     |   6   |        1        | open collector output |
| [7414](7414.md)     |   6   |        1        | Schmitt trigger       |
| [744049](744049.md) |   6   |        1        | atypical pin layout   |
