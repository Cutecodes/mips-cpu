# circ7400
A collection of 7400 series logic chips for use with logisim
